from flask.helpers import get_root_path
import numpy as np
import pandas as pd

aqi_point_df = pd.read_csv(get_root_path(__name__) + "/assets/data/map/processed_df_with_latlng.csv")
def aqi_list():
    return 0