from flask import Blueprint, render_template, request, redirect
from flask.json import jsonify
import app.preprocessing as pp

# Initialize blueprint
main_app = Blueprint("main", __name__, static_folder = "/", template_folder = "templates")

@main_app.route("/")
def index():
    return redirect("/map")

@main_app.route("/map")
def map():
    return render_template("map.html")

@main_app.route("/aqi_query", methods = ["POST"])
def aqiquery():
    return pp.aqi_list()

@main_app.route("/analytics")
def analytics():
    return render_template("analytics.html", city_list = pp.city_list)

@main_app.route("/data_table", methods = ["POST"])
def datatable():
    return pp.data_table()

@main_app.route("/feature_selection", methods = ["POST"])
def fs():
    return pp.fs_chart()

@main_app.route("/correlation", methods = ["POST"])
def corr():
    return pp.corr_chart()

@main_app.route("/date_slider", methods = ["POST"])
def dateslider():
    return pp.create_date_slider()

@main_app.route("/aqi_line_city", methods = ["POST"])
def aqi_line_city():
    selected_start_date = request.form["selected_start_date"]
    selected_end_date = request.form["selected_end_date"]
    selected_city = request.form["selected_city"]
    return pp.aqi_line_city_chart(selected_start_date, selected_end_date, selected_city)

@main_app.route("/dist_aqi", methods = ["POST"])
def dist_aqi():
    selected_chart_type = request.form["selected_chart"]
    return pp.dist_aqi_chart(selected_chart_type)

@main_app.route("/avg_pollutant", methods = ["POST"])
def avg_pollutant():
    return pp.avg_pollutant_chart()

@main_app.route("/ttl_aqi", methods = ["POST"])
def ttl_aqi():
    return pp.ttl_aqi_chart()

@main_app.route("/scatter_aqi", methods = ["POST"])
def scatter_aqi():
    return pp.scatter_aqi_chart()

@main_app.route("/init_pollutant_slider", methods = ["POST"])
def init_pollutant_slider():
    return pp.create_pollutant_slider()

@main_app.route("/predict", methods = ["POST"])
def aqi_prediction():
    model_sequence = int(request.form["model_sequence"])
    model_param_list = ["pm2_5_val", "co_val", "o3_val", "nox_val", "no2_val", "so2_val", "month_val"]
    model_param = {}
    for i in range(0, len(model_param_list)):
        curr_param = model_param_list[i]
        if i+1 <= model_sequence:
            model_param[curr_param] = float(request.form[curr_param])
    return pp.run_aqi_prediction(model_sequence, model_param)

@main_app.route("/about-us")
def about():
    return render_template("about_us.html")