//#region datatable
function executeDataTable() {
    console.log("Querying Data Table...");
    $.ajax({
        url: "/data_table",
		type: "POST",
		dataType: "json",
		success: function (data) {
            let index_mapping = {
                "City": 0,
                "Date": 1,
                "month": 2,
                "PM2_5": 3,
                "NO": 4,
                "NO2": 5,
                "NOx": 6,
                "CO": 7,
                "SO2": 8,
                "O3": 9,
                "AQI": 10,
                "AQI_Bucket": 11,
                "New_AQI": 12
            };
            $("#dataTable").DataTable().clear().destroy();
            $("#dataTable").DataTable({
				data: data["table"],
				columns: [
                    { data: "City" },
                    { data: "Date", 
                    render: function (data, type, row) {
						return data.slice(0,10)
						}
					},
					{ data: "month" },
					{ data: "PM2_5",
                        render: function (data, type, row) {
						    return numeral(data).format("0.00")
					    }
                    },
                    { data: "NO",
                        render: function (data, type, row) {
                            return numeral(data).format("0.00")
                        }
                    },
					{ data: "NO2",
                        render: function (data, type, row) {
                            return numeral(data).format("0.00")
                        }
                    },
					{ data: "NOx",
                        render: function (data, type, row) {
                            return numeral(data).format("0.00")
                        }
                    },
                    { data: "CO",
                        render: function (data, type, row) {
                            return numeral(data).format("0.00")
                        }
                    },
                    { data: "SO2",
                        render: function (data, type, row) {
                            return numeral(data).format("0.00")
                        }
                    },
                    { data: "O3",
                        render: function (data, type, row) {
                            return numeral(data).format("0.00")
                        }
                    },
                    { data: "AQI",
                        render: function (data, type, row) {
                            return numeral(data).format("0")
                        }
                    },
                    { data: "AQI_Bucket" },
                    { data: "New_AQI" }
				],
                createdRow: function(row, data, index) {
                    $.each(data, function(key, value) {
                        if (key == "AQI_Bucket") {
                            $("td", row).eq(index_mapping[key]).css("background-color", categoryColor(value));
                            $("td", row).eq(index_mapping["AQI"]).css("background-color", categoryColor(value));
                            $("td", row).eq(index_mapping[key]).css("color", wordColor(value));
                            $("td", row).eq(index_mapping["AQI"]).css("color", wordColor(value));
                        } else if (key == "New_AQI") {
                            $("td", row).eq(index_mapping[key]).css("background-color", categoryColor(value));
                            $("td", row).eq(index_mapping[key]).css("color", wordColor(value));
                        }
                    });
                },
                columnDefs: [
                    { targets: "_all", className: "text-center"}
                ]
			});
        }
    });
}

function categoryColor(aqi_cat) {
    return aqi_cat == "Bad"          ? "#CC0000" :
           aqi_cat == "Severe"       ? "#CC0000" :
           aqi_cat == "Very Poor"    ? "#E06666" :
           aqi_cat == "Poor"         ? "#EA9999" :
           aqi_cat == "Moderate"     ? "#E69138" :
           aqi_cat == "Satisfactory" ? "#FFD966" :
                                       "#27AE60";
}

function wordColor(aqi_cat) {
    return aqi_cat == "Bad"          ? "#F4CCCC" :
           aqi_cat == "Severe"       ? "#F4CCCC" :
           aqi_cat == "Very Poor"    ? "#660000" :
           aqi_cat == "Poor"         ? "#990000" :
           aqi_cat == "Moderate"     ? "#F9CB9C" :
           aqi_cat == "Satisfactory" ? "#BF9000" :
                                       "#327A50";
}

//#endregion

//#region feature selection chart
function executeFeatureSelectionQuery() {
    console.log("Querying Feature Selection...");
    $.ajax({
        url: "/feature_selection",
        type: "POST",
        dataType: "json",
        success: function(data) {
            for (key in data) {
                let num = key.split("_")[1];
                $("#fs_title_" + num).text(data[key].title);
                Plotly.newPlot(document.getElementById("fs_fig_" + num), data[key].figure.data, data[key].figure.layout, data[key].config);
            }
        }
    });
}

//#endregion

//#region correlation chart
function executeCorrelationQuery() {
    console.log("Querying Correlation Analysis...");
    $.ajax({
        url: "/correlation",
        type: "POST",
        dataType: "json",
        success: function(data) {
            for (key in data) {
                let num = key.split("_")[1];
                $("#corr_title_" + num).text(data[key].title);
                Plotly.newPlot(document.getElementById("corr_fig_" + num), data[key].figure.data, data[key].figure.layout, data[key].config);
            }
        }
    });
}

//#endregion

//#region aqi line chart with city dropdown
var aqi_line_city_ajax = {
    callback: function (data) {
        for (key in data) {
            let num = key.split("_")[1];
            $("#aqi_line_city_title_" + num).text(data[key].title);
            Plotly.newPlot(document.getElementById("aqi_line_city_fig_" + num), data[key].figure.data, data[key].figure.layout, data[key].config);
        }
    }
};
var selected_city = "Ahmedabad";
$("#aqi-line-city-toggle :button").text(selected_city);
$("#aqi-line-city-toggle a").click(function() {
    selected_city = this.getAttribute("value");
    $("#aqi-line-city-toggle :button").text(selected_city);
    let to_send = {
        'selected_start_date': dateSlider.noUiSlider.get()[0],
        'selected_end_date': dateSlider.noUiSlider.get()[1],
        'selected_city': selected_city
    };
    $.ajax({
        url: "/aqi_line_city",
        type: "POST",
        data: to_send,
        dataType: "json",
        success: aqi_line_city_ajax.callback
    });
});

// Date Slider Initialization
var dateSlider = document.getElementById('slider-with-date');

// Get range infos at html (OUTPUT TO HTML)
var dateValues = [document.getElementById('event-start'), document.getElementById('event-end')];

var temp_end_date = new Date(2019, 1, 1);
var temp_start_date = new Date(2019, 0, 1);

// Define Months
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

noUiSlider.create(dateSlider, {
    behaviour: 'tap',
    direction: "ltr",
    connect: true,
    range: {
        min: timestamp(temp_start_date),
        max: timestamp(temp_end_date)
    },
    step: 1 * 24 * 60 * 60 * 1000,
    start: [timestamp(temp_start_date), timestamp(temp_end_date)]
});

dateSlider.noUiSlider.on('update', function (values, handle) {
    dateValues[handle].innerHTML = formatDate(new Date(+values[handle]));
});

// Based on this link: https://refreshless.com/nouislider/events-callbacks/, using "change" will be a better way to plot chart as it will be called whenever there is an interaction
dateSlider.noUiSlider.on("change", function (values, handle) {
    // TRIGGER DATAFRAME UPDATE HERE
    executeAQIQuery(values[0], values[1], selected_city);
})

// Date Slider Initial date value
$.ajax({
    url: "/date_slider",
    type: "POST",
    dataType: "json",
    success: function(data) {
        dateSlider.noUiSlider.updateOptions({
            range: {
                min: timestamp(data.start_date),
                max: timestamp(data.end_date)
            },
            step: 1 * 24 * 60 * 60 * 1000,
            start: [timestamp(data.selected_start_date), timestamp(data.selected_end_date)]
        });
    }
});

// Create a new date from a string, return as a timestamp.
function timestamp(str) {
    return new Date(str).getTime();
}

// Append a suffix to dates. Example: 23 => 23rd, 1 => 1st.
function nth(d) {
    if (d > 3 && d < 21) return 'th';
    switch (d % 10) {
      case 1:
        return "st";
      case 2:
        return "nd";
      case 3:
        return "rd";
      default:
        return "th";
    }
}

// Create a string representation of the date.
function formatDate(date) {
    return date.getDate() + nth(date.getDate()) + " " + months[date.getMonth()] + " " + date.getFullYear();
}


function executeDateSliderQuery() {
    console.log("Querying Date Slider...");
    $.ajax({
        url: "/date_slider",
        type: "POST",
        dataType: "json",
        success: function(data) {
            dateSlider.noUiSlider.updateOptions({
                range: {
                    min: timestamp(data.start_date),
                    max: timestamp(data.end_date)
                },
                step: 1 * 24 * 60 * 60 * 1000,
                start: [timestamp(data.selected_start_date), timestamp(data.selected_end_date)]
            });
            executeAQIQuery(dateSlider.noUiSlider.get()[0], dateSlider.noUiSlider.get()[1], selected_city);
        }
    });
}

function executeAQIQuery(start_date, end_date, city) {
    console.log("Querying AQI Line chart with city dropdown...");
    let to_send = {
        'selected_start_date': start_date,
        'selected_end_date': end_date,
        'selected_city': city
    };
    $.ajax({
        url: "/aqi_line_city",
        type: "POST",
        data: to_send,
        dataType: "json",
        success: aqi_line_city_ajax.callback
    });
}

//#endregion

//#region distribution of aqi group
var dist_chart_type_ajax = {
    callback: function (data) {
        for (key in data) {
            let num = key.split("_")[1];
            $("#dist_aqi_title_" + num).text(data[key].title);
            Plotly.newPlot(document.getElementById("dist_aqi_fig_" + num), data[key].figure.data, data[key].figure.layout, data[key].config);
        }
    }
};
var selected_dist_chart_type = "pie";
$("#dist-chart-type-toggle :button").click(function() {
    selected_dist_chart_type = this.getAttribute("value");
    let to_send = {
        "selected_chart": selected_dist_chart_type
    };
    $.ajax({
        url: "/dist_aqi",
        type: "POST",
        data: to_send,
        dataType: "json",
        success: dist_chart_type_ajax.callback
    });
});

function executeDistributionAQIGroup() {
    console.log("Querying Distribution of AQI Group...");
    let to_send = {
        "selected_chart": selected_dist_chart_type
    };
    $.ajax({
        url: "/dist_aqi",
        type: "POST",
        data: to_send,
        dataType: "json",
        success: dist_chart_type_ajax.callback
    });
}

//#endregion

//#region average pollutant per month in overall India
function executeAveragePollutant() {
    console.log("Querying Average Pollutant per Month...");
    $.ajax({
        url: "/avg_pollutant",
        type: "POST",
        dataType: "json",
        success: function(data) {
            for (key in data) {
                let num = key.split("_")[1];
                $("#avg_pollutant_title_" + num).text(data[key].title);
                Plotly.newPlot(document.getElementById("avg_pollutant_fig_" + num), data[key].figure.data, data[key].figure.layout, data[key].config);
            }
        }
    });
}

//#endregion

//#region total number of each aqi category for each city
function executeTotalAQI() {
    console.log("Querying Total AQI category...");
    $.ajax({
        url: "/ttl_aqi",
        type: "POST",
        dataType: "json",
        success: function(data) {
            for (key in data) {
                let num = key.split("_")[1];
                $("#ttl_aqi_title_" + num).text(data[key].title);
                Plotly.newPlot(document.getElementById("ttl_aqi_fig_" + num), data[key].figure.data, data[key].figure.layout, data[key].config);
            }
        }
    })
}

//#endregion

//#region scatterplot of aqi vs pollutants
function executeScatterAQI() {
    console.log("Querying Scatterplot AQI...");
    $.ajax({
        url: "/scatter_aqi",
        type: "POST",
        dataType: "json",
        success: function(data) {
            for (key in data) {
                let num = key.split("_")[1];
                $("#scatter_aqi_title_" + num).text(data[key].title);
                Plotly.newPlot(document.getElementById("scatter_aqi_fig_" + num), data[key].figure.data, data[key].figure.layout, data[key].config);
            }
        }
    });
}

//#endregion

//#region prediction
// Pollutant Slider Initialization
var pm2_5_slider = document.getElementById('pm2-5-slider');
var co_slider = document.getElementById("co-slider");
var o3_slider = document.getElementById("o3-slider");
var nox_slider = document.getElementById("nox-slider");
var no2_slider = document.getElementById("no2-slider");
var so2_slider = document.getElementById("so2-slider");
var month_slider = document.getElementById("month-slider");

// Get range infos at html (OUTPUT TO HTML)
var pm2_5_values = document.getElementById('pm2-5-val');
var co_values = document.getElementById('co-val');
var o3_values = document.getElementById('o3-val');
var nox_values = document.getElementById('nox-val');
var no2_values = document.getElementById('no2-val');
var so2_values = document.getElementById('so2-val');
var month_values = document.getElementById('month-val');

noUiSlider.create(pm2_5_slider, {
    behaviour: 'tap',
    direction: 'ltr',
    start: 0,
    range: {
        min: 0,
        max: 1
    }
});
noUiSlider.create(co_slider, {
    behaviour: 'tap',
    direction: 'ltr',
    start: 0,
    range: {
        min: 0,
        max: 1
    }
});
noUiSlider.create(o3_slider, {
    behaviour: 'tap',
    direction: 'ltr',
    start: 0,
    range: {
        min: 0,
        max: 1
    }
});
noUiSlider.create(nox_slider, {
    behaviour: 'tap',
    direction: 'ltr',
    start: 0,
    range: {
        min: 0,
        max: 1
    }
});
noUiSlider.create(no2_slider, {
    behaviour: 'tap',
    direction: 'ltr',
    start: 0,
    range: {
        min: 0,
        max: 1
    }
});
noUiSlider.create(so2_slider, {
    behaviour: 'tap',
    direction: 'ltr',
    start: 0,
    range: {
        min: 0,
        max: 1
    }
});
noUiSlider.create(month_slider, {
    behaviour: 'tap',
    direction: 'ltr',
    start: 0,
    range: {
        min: 0,
        max: 1
    }
});

pm2_5_slider.noUiSlider.on('update', function (values) {pm2_5_values.innerHTML = values;});
co_slider.noUiSlider.on('update', function (values) {co_values.innerHTML = values;});
o3_slider.noUiSlider.on('update', function (values) {o3_values.innerHTML = values;});
nox_slider.noUiSlider.on('update', function (values) {nox_values.innerHTML = values;});
no2_slider.noUiSlider.on('update', function (values) {no2_values.innerHTML = values;});
so2_slider.noUiSlider.on('update', function (values) {so2_values.innerHTML = values;});
month_slider.noUiSlider.on('update', function (values) {month_values.innerHTML = months[parseInt(values-1)];});

// Initailize all pollutant slider
$.ajax({
    url: "/init_pollutant_slider",
    type: "POST",
    dataType: "json",
    success: function(data) {
        pm2_5_slider.noUiSlider.updateOptions({
            range: {
                min: data.pm2_5_min_val,
                max: data.pm2_5_max_val
            },
            start: data.pm2_5_sel_val
        });
        co_slider.noUiSlider.updateOptions({
            range: {
                min: data.co_min_val,
                max: data.co_max_val
            },
            start: data.co_sel_val
        });
        o3_slider.noUiSlider.updateOptions({
            range: {
                min: data.o3_min_val,
                max: data.o3_max_val
            },
            start: data.o3_sel_val
        });
        nox_slider.noUiSlider.updateOptions({
            range: {
                min: data.nox_min_val,
                max: data.nox_max_val
            },
            start: data.nox_sel_val
        });
        no2_slider.noUiSlider.updateOptions({
            range: {
                min: data.no2_min_val,
                max: data.no2_max_val
            },
            start: data.no2_sel_val
        });
        so2_slider.noUiSlider.updateOptions({
            range: {
                min: data.so2_min_val,
                max: data.so2_max_val
            },
            start: data.so2_sel_val
        });
        month_slider.noUiSlider.updateOptions({
            range: {
                min: 1,
                max: 12
            },
            start: 1
        });
    }
});

// Initialize the checkbox
var model_settings = $('input:checkbox[class~="model_setting"]');
model_settings.change(function() {
    let selected_param = parseInt($(this).val());
    
    // If selected: select all above
    if ($('input:checkbox[name~="model_setting"][value="'+selected_param+'"]').prop("checked") == true) {
        for (let i = selected_param-1; i >= 1; i--) {
            let prev_checkbox = $('input:checkbox[name~="model_setting"][value="'+i+'"]');
            if (prev_checkbox.prop("checked") == false) {
                prev_checkbox.prop("checked", !prev_checkbox.prop("checked"));
            }
        }
    } else {  // If not deselect: deselect all below
        for (let i = selected_param; i <= 7; i++) {
            let prev_checkbox = $('input:checkbox[name~="model_setting"][value="'+i+'"]');
            if (prev_checkbox.prop("checked") == true) {
                prev_checkbox.prop("checked", !prev_checkbox.prop("checked"));
            }
        }
    }
});

$("#predict-btn").click(function() {
    let model_sequence = $('input:checkbox[name~="model_setting"]:checked').length;
    let month_val, so2_val, no2_val, nox_val, o3_val, co_val, pm2_5_val;
    for (let i = model_sequence; i >= 1; i--) {
        if (i == 7) {
            month_val = month_slider.noUiSlider.get();
        } else if (i == 6) {
            so2_val = so2_slider.noUiSlider.get();
        } else if (i == 5) {
            no2_val = no2_slider.noUiSlider.get();
        } else if (i == 4) {
            nox_val = nox_slider.noUiSlider.get();
        } else if (i == 3) {
            o3_val = o3_slider.noUiSlider.get();
        } else if (i == 2) {
            co_val = co_slider.noUiSlider.get();
        } else if (i == 1) {
            pm2_5_val = pm2_5_slider.noUiSlider.get();
        }
    }

    let to_send = {
        model_sequence: model_sequence,
        month_val: month_val,
        so2_val: so2_val,
        no2_val: no2_val,
        nox_val: nox_val,
        o3_val: o3_val,
        co_val: co_val,
        pm2_5_val: pm2_5_val
    };

    $.ajax({
        url: "/predict",
        type: "POST",
        data: to_send,
        dataType: "json",
        success: function(data) {
            $("#pred-result").text(data["y_pred"]);
            $("#pred-result").css("color", categoryColor(data["y_pred"]));
            $("#pred-text").html(
                'The prediction is made using <strong>' + data["model_name"] + 
                '</strong> algorithm with <strong>' + data["model_sequence"] + 
                '</strong> variables as the input to the model. The model has achieved accuracy of <strong>' + numeral(data["model_score"]).format("0.00%") + 
                '</strong>.'
            );
        }
    });
});

//#endregion

$(document).ready(function() {
    var table = $('#dataTable').DataTable();
    executeDateSliderQuery();
    executeDataTable();
    executeFeatureSelectionQuery();
    executeCorrelationQuery();
    executeDistributionAQIGroup();
    executeAveragePollutant();
    executeTotalAQI();
    executeScatterAQI();
});