function initMap() {
    var gmap = L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',{
        maxZoom: 18,
        minZoom: 2,
        subdomains: ["mt0", "mt1", "mt2", "mt3"]
    });

    var Esri_WorldImagery = L.tileLayer("http://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
        attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
    });

    var baseLayers = {
        "Default": gmap,
        "Satelite": Esri_WorldImagery
    };

    var latlng = L.latLng(20.59, 78.92);
    var map = L.map('map', {
        center: latlng,
        zoom: 5,
        fullscreenControl: false,
        layers: [gmap]
    });

    var layerControl = L.control.layers(baseLayers);
    layerControl.addTo(map);

    return {
        map: map,
        layerControl: layerControl
    };
}

// Map Initialization
var mapStuff = initMap();
var map = mapStuff.map;
var layerControl = mapStuff.layerControl;
var aqi_layer = {
    "Good": L.layerGroup(),
    "Satisfactory": L.layerGroup(),
    "Moderate": L.layerGroup(),
    "Bad": L.layerGroup()
};

// CHOROPLETH
var legend = L.control({position: 'bottomright'});
legend.onAdd = function (map) {
    var div = L.DomUtil.create('div', 'info legend');
    div.innerHTML = `
        <div class="customrow">
            <b style="color: #566C84;"> AQI Marker</b>
        </div>
        <div class="customrow">
            <label for="aqi_good" class="customrow">
                <input type="checkbox" class="aqi_setting" id="aqi_good" name="aqi_setting" value="Good"></input>
                <div style="padding-left:10px;">
                    <i style="background: #27AE60;"></i>
                    <span> Good</span>
                </div>
            </label>
        </div>
        <div class="customrow">
            <label for="aqi_satisfactory" class="customrow">
                <input type="checkbox" class="aqi_setting" id="aqi_satisfactory" name="aqi_setting" value="Satisfactory"></input>
                <div style="padding-left:10px;">
                    <i style="background: #FFD966;"></i>
                    <span> Satisfactory</span>
                </div>
            </label>
        </div>
        <div class="customrow">
            <label for="aqi_moderate" class="customrow">
                <input type="checkbox" class="aqi_setting" id="aqi_moderate" name="aqi_setting" value="Moderate"></input>
                <div style="padding-left:10px;">
                    <i style="background: #E69138;"></i>
                    <span> Moderate</span>
                </div>
            </label>
        </div>
        <div class="customrow">
            <label for="aqi_bad" class="customrow">
                <input type="checkbox" class="aqi_setting" id="aqi_bad" name="aqi_setting" value="Bad" checked disabled></input>
                <div style="padding-left:10px;">
                    <i style="background: #CC0000;"></i>
                    <span> Bad</span>
                </div>
            </label>
        </div>
    `;
    return div;
};
legend.addTo(map);
var aqi_settings = $('input:checkbox[class~="aqi_setting"]');

aqi_settings.change(function() {
    // If only 1 checked left, then disable it to prevent empty chart
    if ($('input:checkbox[name~="aqi_setting"]:checked').length == 1) {
        $('input:checkbox[name~="aqi_setting"]:checked').attr("disabled", true);
    } else {
        aqi_settings.removeAttr("disabled");
    }

    let selected_setting = $(this).val();
    // Not using for loop as this is checkboxes
    if (map.hasLayer(aqi_layer[selected_setting])) {
        map.removeLayer(aqi_layer[selected_setting]);
    } else {
        aqi_layer[selected_setting].addTo(map);
    }
});

function executeAQIQuery() {
    console.log("Querying AQI...");
    $.ajax({
        url: "/aqi_query",
        type: "POST",
        dataType: "json",
        success: function(data) {
            var aqi_df = data["result"];
            console.log("Entered");
            for (var i = 0; i < aqi_df.length; i++) {
                var tooltip = "<h5>" + aqi_df[i].City + "</h5>" + 
                              "<h6>Location: " + aqi_df[i].lat + ", " + aqi_df[i].lng + "</h6>" + 
                              "<h6>Predicted AQI Category: <span style='color:" + circleColor(aqi_df[i].pred_New_AQI) + ";'>" + aqi_df[i].pred_New_AQI + "</span></h6>" + 
                              "<h6>Actual AQI Category: <span style='color:" + circleColor(aqi_df[i].New_AQI) + ";'>" + aqi_df[i].New_AQI + "</span></h6>";
                L.circleMarker(new L.LatLng(aqi_df[i].lat, aqi_df[i].lng), {color: circleColor(aqi_df[i].New_AQI), weight: 1, fillOpacity: 0.6}).addTo(aqi_layer[aqi_df[i].New_AQI]).bindPopup(tooltip, {maxWidth: 1000});
            }
        }
    });
    aqi_layer["Bad"].addTo(map);
}

function circleColor(aqi_cat) {
    return aqi_cat == "Bad"          ? "#CC0000" :
           aqi_cat == "Moderate"     ? "#E69138" :
           aqi_cat == "Satisfactory" ? "#FFD966" :
                                       "#27AE60";
}

$(document).ready(function() {
    executeAQIQuery();
});