from flask import Flask
from app.main import main_app

def create_app():
    server = Flask(__name__, static_folder = "/")
    register_blueprints(server)

    return server

def register_blueprints(server):
    server.register_blueprint(main_app)