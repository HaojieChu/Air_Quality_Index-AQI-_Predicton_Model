from flask.helpers import get_root_path
import numpy as np
import pandas as pd
import json
import plotly.graph_objs as go
import plotly.io as pio
from plotly.subplots import make_subplots
from plotly.utils import PlotlyJSONEncoder
import pickle
from glob import glob
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Define Plotly Themes
pio.templates["custom"] = pio.templates["plotly"]
pio.templates["custom"]["layout"]["plot_bgcolor"] = "white"
pio.templates["custom"]["layout"]["legend"] = dict(
    orientation = "h",
    yanchor = "top",
    xanchor = "left",
    x = 0,
    y = -0.2
)
pio.templates["custom"]["layout"]["xaxis"] = dict(
    gridcolor = "lightgrey",
    linecolor = "grey",
    linewidth = 1,
    showline = True,
    mirror = True,
    title = dict(
        standoff = 0
    )
)
pio.templates["custom"]["layout"]["yaxis"] = dict(
    gridcolor = "lightgrey",
    linecolor = "grey",
    linewidth = 1,
    showline = True,
    mirror = True,
    title = dict(
        standoff = 0
    )
)
pio.templates["custom"]["layout"]["margin"] = dict(
    t = 5,
    l = 80,
    b = 50,
    r = 50
)
pio.templates.default = "custom"

default_config = dict(
    displayModeBar = False, 
    responsive = True
)

# Read dataframe
aqi_point_df = pd.read_csv(get_root_path(__name__) + "/assets/data/processed_test_df.csv")
aqi_df = pd.read_csv(get_root_path(__name__) + "/assets/data/processed_df.csv")
fs_df = pd.read_csv(get_root_path(__name__) + "/assets/data/fs_df.csv")

# Process the dataset
to_drop = ["City", "Date", "NO", "AQI", "AQI_Bucket"]
to_drop_df = aqi_df[to_drop].copy()
temp_aqi_df = aqi_df.drop(to_drop, axis = 1)
y = temp_aqi_df["New_AQI"]
X = temp_aqi_df.drop(["New_AQI"], axis = 1)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 22)

# Read and prepare the model
model_list = {}
for file_path in glob(get_root_path(__name__) + "/assets/data/model/*"):
    model_file = file_path.split("/")[-1]
    model_sequence = int(model_file.split("_")[1])
    model_name = (model_file.split("_")[2]).split(".")[0]
    model = pickle.load(open(file_path, "rb"))
    selected_col = fs_df.iloc[:model_sequence].col.values
    y_pred = model.predict(X_test.loc[:, selected_col])
    score = accuracy_score(y_test, y_pred)
    if model_name == "NB":
        new_model_name = "Naive Bayes"
    elif model_name == "RF":
        new_model_name = "RandomForest"
    elif model_name == "LGBM":
        new_model_name = "LightGBM"
    elif model_name == "CART":
        new_model_name = "Classification and Regression Tree"
    elif model_name == "XGB":
        new_model_name == "XGBoost"

    model_list[model_sequence] = dict(
        name=new_model_name,
        model=model,
        score=score
    )

city_list = sorted(aqi_df.City.unique().tolist())
default_selected_pollutants = ["PM2.5", "CO", "NO2", "O3"]

# Map AQI points
def aqi_list():
    return {"result": json.loads(aqi_point_df.to_json(orient = "records"))}

# Analytics
# Date slider
def create_date_slider():
    temp = aqi_df.copy()
    temp["Date"] = pd.to_datetime(temp["Date"])
    temp = temp.sort_values(by = "Date")
    end_date = pd.to_datetime(temp.tail(1).Date.values[0])
    start_date = pd.to_datetime(temp.head(1).Date.values[0])
    selected_end_date = end_date
    selected_start_date = start_date
    date_slider = dict(start_date=start_date, end_date=end_date, selected_start_date=selected_start_date, selected_end_date=selected_end_date)
    return date_slider

# Data table
def data_table():
    new_df = aqi_df.copy()
    new_df = new_df.rename(columns = {"PM2.5": "PM2_5"})
    return {"table": json.loads(new_df.to_json(orient = "records"))}

# Feature importance
def fs_chart():
    data = [
        go.Bar(
            x = fs_df["col"],
            y = fs_df["importance"],
            hovertemplate = "Variable: %{x}<br>Importance value: %{y}<extra></extra>"
        )
    ]
    layout = go.Layout(
        xaxis_title = "Variable",
        yaxis_title = "Importance Value"
    )
    fig = go.Figure(data=data, layout=layout)
    fig_1 = dict(figure=fig, config=default_config, title="Feature Importance Ranking")

    fs_dict = json.dumps(dict(fig_1=fig_1), cls=PlotlyJSONEncoder)

    return fs_dict

# Correlation analysis
def corr_chart():
    corr_val = aqi_df[["PM2.5", "NO", "NO2", "NOx", "CO", "SO2", "O3"]].corr()
    data = [
        go.Heatmap(
            z=corr_val,
            x=["PM2.5", "NO", "NO2", "NOx", "CO", "SO2", "O3"],
            y=["PM2.5", "NO", "NO2", "NOx", "CO", "SO2", "O3"],
            hovertemplate="Correlation value between %{x} and %{y} = %{z}<extra></extra>"
        )
    ]
    layout = go.Layout(yaxis_autorange = "reversed")
    fig = go.Figure(data=data, layout=layout)
    fig_1 = dict(figure=fig, config=default_config, title="Correlation Graph Between Features")

    corr_dict = json.dumps(dict(fig_1=fig_1), cls=PlotlyJSONEncoder)

    return corr_dict

# AQI Line chart
def aqi_line_city_chart(selected_start_date, selected_end_date, selected_city):
    selected_start_date = pd.to_datetime(selected_start_date, unit = "ms")
    selected_end_date = pd.to_datetime(selected_end_date, unit = "ms")
    subset_df = aqi_df.copy()
    subset_df["Date"] = pd.to_datetime(subset_df["Date"])
    subset_df = subset_df.loc[((subset_df.City == selected_city) & (subset_df.Date >= selected_start_date) & (subset_df.Date <= selected_end_date)), ["Date", "PM2.5", "NO", "NO2", "NOx", "CO", "SO2", "O3"]].copy()
    subset_df = subset_df.sort_values(by = "Date")
    data = []
    for col in ["PM2.5", "NO", "NO2", "NOx", "CO", "SO2", "O3"]:
        if col in default_selected_pollutants:
            trace = go.Scatter(
                x = subset_df["Date"],
                y = subset_df[col],
                name = col,
                hovertemplate = "Date: %{x}<br>Pollutant: %{customdata}<br>Value: %{y}<extra></extra>",
                customdata = np.repeat(col, len(subset_df))
            )
        else:
            trace = go.Scatter(
                x = subset_df["Date"],
                y = subset_df[col],
                name = col,
                hovertemplate = "Date: %{x}<br>Pollutant: %{customdata}<br>Value: %{y}<extra></extra>",
                customdata = np.repeat(col, len(subset_df)),
                visible = "legendonly"
            )
        data.append(trace)

    layout = go.Layout(
        xaxis_title = "Date",
        yaxis_title = "Pollutant Value"
    )

    fig1 = go.Figure(data=data, layout=layout)
    fig_1 = dict(figure=fig1, config=default_config, title="Pollutant Value Across Time in {}".format(selected_city))

    aqi_line_city_dict = json.dumps(dict(fig_1=fig_1), cls=PlotlyJSONEncoder)

    return aqi_line_city_dict

# Distribution of AQI category
def rank_target(x):
    if x == "Good":
        return 1
    elif x == "Satisfactory":
        return 2
    elif x == "Moderate":
        return 3
    elif x == "Poor":
        return 4
    elif x == "Very Poor":
        return 5
    else:
        return 6

def dist_aqi_chart(selected_chart_type):
    temp = aqi_df.AQI_Bucket.value_counts().reset_index()
    temp["rank"] = temp["index"].apply(rank_target)
    temp = temp.sort_values(by="rank")

    temp2 = aqi_df.New_AQI.value_counts().reset_index()
    temp2["rank"] = temp2["index"].apply(rank_target)
    temp2 = temp2.sort_values(by="rank")

    if selected_chart_type == "line":
        fig = make_subplots(rows = 1, cols = 2)
        fig.append_trace(
            go.Bar(
                x = temp["index"],
                y = temp["AQI_Bucket"],
                marker_color = ["#00CC96", "#636EFA", "#AB63FA", "#FFA15A", "#FF6692", "#EF553B"],
                hovertemplate = "Previous AQI Category: %{x}<br>Number of Observations: %{y}<extra></extra>"
            ),
            row = 1,
            col = 1
        )
        fig.append_trace(
            go.Bar(
                x = temp2["index"],
                y = temp2["New_AQI"],
                marker_color = ["#00CC96", "#636EFA", "#AB63FA", "#EF553B"],
                hovertemplate = "New AQI Category: %{x}<br>Number of Observations: %{y}<extra></extra>"
            ),
            row = 1,
            col = 2
        )
    else:
        data = [
            go.Pie(
                labels = temp["index"],
                values = temp["AQI_Bucket"],
                domain=dict(x=[0, 0.4]),
                marker_colors = ["#00CC96", "#636EFA", "#AB63FA", "#FFA15A", "#FF6692", "#EF553B"],
                hovertemplate = "Previous AQI Category: %{label}<br>Number of Observations: %{value} (%{percent})<extra></extra>",
                hole = 0.5,
                direction = "counterclockwise",
                rotation = -90
            ),
            go.Pie(
                labels = temp2["index"],
                values = temp2["New_AQI"],
                domain=dict(x=[0.6, 1]),
                marker_colors = ["#00CC96", "#636EFA", "#AB63FA", "#EF553B"],
                hovertemplate = "Previous AQI Category: %{label}<br>Number of Observations: %{value} (%{percent})<extra></extra>",
                hole = 0.5,
                direction = "counterclockwise",
                rotation = -90
            )
        ]
        fig = go.Figure(data=data)
    
    fig.update_layout(yaxis_title = "Number of Observations", showlegend=False)

    fig_1 = dict(figure=fig, config=default_config, title="Distribution of Previous vs Current AQI Group")
    dist_aqi_dict = json.dumps(dict(fig_1=fig_1), cls=PlotlyJSONEncoder)

    return dist_aqi_dict

# Average pollutant per month for overall India
def avg_pollutant_chart():
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    subset_df = aqi_df.groupby("month").mean().reset_index()[["month", "PM2.5", "NO", "NO2", "NOx", "CO", "SO2", "O3"]].copy()
    subset_df["new_month"] = subset_df["month"].apply(lambda x: months[x-1])
    data = []
    for col in ["PM2.5", "NO", "NO2", "NOx", "CO", "SO2", "O3"]:
        trace = go.Scatter(
            x = subset_df["new_month"],
            y = subset_df[col],
            name = col,
            hovertemplate = "Month: %{x}<br>Pollutant: %{customdata}<br>Average Pollutant Value: %{y}<extra></extra>",
            customdata = np.repeat(col, len(subset_df))
        )
        data.append(trace)

    layout = go.Layout(
        xaxis_title = "Month",
        yaxis_title = "Average Pollutant Value"
    )

    fig1 = go.Figure(data=data, layout=layout)
    fig_1 = dict(figure=fig1, config=default_config, title="Average Pollutant Value per Month")

    avg_pollutant_dict = json.dumps(dict(fig_1=fig_1), cls=PlotlyJSONEncoder)

    return avg_pollutant_dict

# Number of each AQI category by city
def ttl_aqi_chart():
    temp = aqi_df.groupby("City").New_AQI.value_counts().reset_index(name="number_of_obs")
    
    data = []
    aqi_list = temp.New_AQI.unique().tolist()
    for i in range(len(aqi_list)):
        aqi = aqi_list[i]
        temp2 = temp[temp["New_AQI"] == aqi].copy()
        if aqi == "Good":
            color = "#00CC96"
        elif aqi == "Bad":
            color = "#EF553B"
        elif aqi == "Moderate":
            color = "#AB63FA"
        elif aqi == "Satisfactory":
            color = "#636EFA"
        trace = go.Bar(
            x = temp2.City,
            y = temp2.number_of_obs,
            name = aqi,
            offsetgroup = i,
            marker_color = color,
            hovertemplate = "City: %{x}<br>AQI Category: %{customdata}<br>Number of Observations: %{y}<extra></extra>",
            customdata = np.repeat(aqi, len(temp2))
        )
        data.append(trace)
    layout = go.Layout(
        xaxis_title = "City",
        yaxis_title = "Number of Observations"
    )
    fig = go.Figure(data=data, layout=layout)
    fig_1 = dict(figure=fig, config=default_config, title="Number of Each AQI Category in Each City")
    ttl_aqi_dict = json.dumps(dict(fig_1=fig_1), cls=PlotlyJSONEncoder)

    return ttl_aqi_dict

# Scatterplot of AQI vs pollutants
def scatter_aqi_chart():
    fig = make_subplots(rows = 3, cols = 3)
    pollutant_list = ["PM2.5", "NO", "NO2", "NOx", "CO", "SO2", "O3"]
    aqi_list = aqi_df.New_AQI.unique().tolist()
    for i in range(len(pollutant_list)):
        pollutant = pollutant_list[i]
        for aqi in aqi_list:
            if aqi == "Good":
                color = "#00CC96"
            elif aqi == "Bad":
                color = "#EF553B"
            elif aqi == "Moderate":
                color = "#AB63FA"
            elif aqi == "Satisfactory":
                color = "#636EFA"
            subset_df = aqi_df[aqi_df.New_AQI == aqi].copy()
            fig.append_trace(
                go.Scattergl(
                    x = subset_df["AQI"], 
                    y = subset_df[pollutant], 
                    mode="markers", 
                    marker_color = color, 
                    name = aqi, 
                    showlegend=True if pollutant == "PM2.5" else False,
                    hovertemplate="AQI:%{x}<br>%{customdata}:%{y}<extra></extra>", 
                    customdata = np.repeat(pollutant, len(subset_df)),
                    legendgroup=aqi
                ),
                row=int((i / 3) + 1), 
                col=(i % 3) + 1
            )
    for i in range(len(pollutant_list)):
        fig["layout"]["yaxis"+str(i+1)]["title"] = pollutant_list[i]
    
    fig_1 = dict(figure=fig, config=default_config, title="Scatterplot of AQI vs Pollutants")
    scatter_aqi_dict = json.dumps(dict(fig_1=fig_1), cls=PlotlyJSONEncoder)

    return scatter_aqi_dict

# Prediction part
def create_pollutant_slider():
    temp = X_test.describe()

    pollutant_dict = dict(
        pm2_5_min_val=temp.loc["min", "PM2.5"], pm2_5_max_val=temp.loc["max", "PM2.5"], pm2_5_sel_val=round(temp.loc["mean", "PM2.5"], 2),\
        co_min_val=temp.loc["min", "CO"], co_max_val=temp.loc["max", "CO"], co_sel_val=round(temp.loc["mean", "CO"], 2),\
        o3_min_val=temp.loc["min", "O3"], o3_max_val=temp.loc["max", "O3"], o3_sel_val=round(temp.loc["mean", "O3"], 2),\
        nox_min_val=temp.loc["min", "NOx"], nox_max_val=temp.loc["max", "NOx"], nox_sel_val=round(temp.loc["mean", "NOx"], 2),\
        no2_min_val=temp.loc["min", "NO2"], no2_max_val=temp.loc["max", "NO2"], no2_sel_val=round(temp.loc["mean", "NO2"], 2),\
        so2_min_val=temp.loc["min", "SO2"], so2_max_val=temp.loc["max", "SO2"], so2_sel_val=round(temp.loc["mean", "SO2"], 2)
    )
    return pollutant_dict


def run_aqi_prediction(model_sequence, model_param):
    temp = pd.DataFrame(pd.Series(model_param)).T
    model = model_list[model_sequence]["model"]
    y_pred = model.predict(temp.values.reshape(1, -1))
    model_name = model_list[model_sequence]["name"]
    model_score = model_list[model_sequence]["score"]
    pred_dict = dict(
        y_pred = y_pred[0],
        model_name = model_name,
        model_score = model_score,
        model_sequence = model_sequence
    )
    
    return pred_dict